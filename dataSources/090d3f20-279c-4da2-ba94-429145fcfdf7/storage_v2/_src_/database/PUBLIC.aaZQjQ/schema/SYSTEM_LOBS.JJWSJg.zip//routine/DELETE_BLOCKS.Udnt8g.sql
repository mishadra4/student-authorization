CREATE PROCEDURE SYSTEM_LOBS.DELETE_BLOCKS(IN L_ID BIGINT, IN B_OFFSET INTEGER, IN B_LIMIT INTEGER, IN TX_ID BIGINT)
  LANGUAGE SQL
  NOT DETERMINISTIC
  MODIFIES SQL DATA
  NEW SAVEPOINT LEVEL BEGIN
  ATOMIC INSERT INTO SYSTEM_LOBS.BLOCKS (BLOCK_ADDR, BLOCK_COUNT, TX_ID) (SELECT BLOCK_ADDR,
                                                                                 BLOCK_COUNT,
                                                                                 TX_ID
                                                                          FROM SYSTEM_LOBS.LOBS
                                                                          WHERE LOBS.LOB_ID = L_ID
                                                                            AND BLOCK_OFFSET >= B_OFFSET
                                                                            AND BLOCK_OFFSET < B_LIMIT);
  DELETE
  FROM SYSTEM_LOBS.LOBS
  WHERE LOBS.LOB_ID = L_ID
    AND BLOCK_OFFSET >= B_OFFSET
    AND BLOCK_OFFSET < B_LIMIT;
END;

